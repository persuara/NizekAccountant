package Login;

public enum GroupTypeItems {
    COSTUMER("مشتری"),
    EMPLOYEE("کارمند"),
    PARTNER("شریک");

    String text;

    GroupTypeItems(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
