package Login;

public class User {
    public static String name;
    public static String nationalID;
    public static GroupType groupType; //needs to be overridden! we need to declare a type!
    public static String address;
    public static String phone;
    public static String email;

    public User(String name, String nationalID, GroupType groupType, String address, String phone, String email) {
        this.name = name;
        this.nationalID = nationalID;
        this.groupType = groupType;
        this.address = address;
        this.phone = phone;
        this.email = email;
    }

    public static String getName() {
        return name;
    }

    public static String getNationalID() {
        return nationalID;
    }

    public static GroupType getGroupType() {
        return groupType;
    }

    public static String getAddress() {
        return address;
    }

    public static String getPhone() {
        return phone;
    }

    public static String getEmail() {
        return email;
    }
}
