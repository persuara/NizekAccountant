package DocModels;

import Date.Date;
import Date.Time;

public class CheckDoc implements  Documentable{
    private String payee;
    private String cost;
    private String description;
    private Date date;
    private Time time;

    public CheckDoc(String payee, String cost, String description, Date date, Time time) {
        this.payee = payee;
        this.cost = cost;
        this.description = description;
        this.date = date;
        this.time = time;
    }

    @Override
    public Date setDate() {
        return null;
    }

    public String getPayee() {
        return payee;
    }

    public String getCost() {
        return cost;
    }

    public String getDescription() {
        return description;
    }

    public Date getDate() {
        return date;
    }

    public Time getTime() {
        return time;
    }
}
