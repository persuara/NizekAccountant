package DocModels;

import Date.Date;
import Date.Time;

public class NormalDoc implements Documentable {
    String payee;
    String cost;
    String description;
    boolean isCreditor;
    Date date;
    Time time;

    public NormalDoc(String payee, String cost, String description,  boolean isCreditor, Date date, Time time) {
        this.payee = payee;
        this.cost = cost;
        this.description = description;
        this.isCreditor = isCreditor;
        this.date = date;
        this.time = time;
    }

    @Override
    public Date setDate() {
        // VALIDATE THIIIIIIIIIIIIIIS
        return null;
    }
}
