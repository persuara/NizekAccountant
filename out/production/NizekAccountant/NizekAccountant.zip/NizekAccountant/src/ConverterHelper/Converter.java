package ConverterHelper;

import Date.Date;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.TimeZone;

public class Converter {
    private final String DATE_FORMAT_PERSIAN = "yyyy-MM-dd HH:mm:ss";
    private final String DATE_FORMAT_UTC = "yyyy-dd-MM HH:mm:ss";

    public Double convertToDouble(String file) {
        return Double.parseDouble(file);
    }
    public String convertToString(Double file) {
        return String.valueOf(file);
    }

}
