package UserRepository;

public interface Reposible {
    void readFile();
   void writeToFile(String file);

}
