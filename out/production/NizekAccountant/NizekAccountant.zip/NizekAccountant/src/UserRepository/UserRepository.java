package UserRepository;

import Login.User;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserRepository implements Reposible {
    List<User> userList = new ArrayList<>();


    public void addUser(User user) {
        userList.add(user);
    }
    public List<User> getUserList() {
        return userList;
    }
    public void deleteUser(User user) {
        userList.remove(user);
    }

    @Override
    public void readFile() {
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(""));

            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void writeToFile(String file) {
//        try {
//            File csvfile = new File("");
//            FileWriter fileWriter = new FileWriter(csvfile);
//            fileWriter.close();
//
//        } catch () {
//            e.printStackTrace();
//        }
    }

}
