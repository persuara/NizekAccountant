package AccountingCalculations;

import Date.Date;
import DocModels.NormalDoc;

public class Accounting {
    NormalDoc normalDoc = new NormalDoc("ali",
            "1000",
            "car payment",
            true, new Date(1,12,1401), )
}
